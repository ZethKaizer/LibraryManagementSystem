<?php 
include "connection.php";
$id = $_GET["id"];
$a = date("d-m-Y");
$res = mysqli_query($link, "UPDATE issue_books SET books_return_date='$a', status='returned' WHERE id=$id");

$books_name = "";
$res = mysqli_query($link, "SELECT * from issue_books WHERE id=$id");
while($row = mysqli_fetch_array($res)) {
	$books_name = $row["books_name"];
}

mysqli_query($link, "UPDATE add_books SET available_qty=available_qty+1 WHERE books_name='$books_name'");

//mysqli_query($link, "DELETE FROM issue_books WHERE id=$id ");
?>

<script>
	window.location = "my_issued_books.php";
</script>