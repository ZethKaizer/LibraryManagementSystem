<?php 
    
    include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Student Registration Form | LMS </title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
   
</head>
<?php 
    include('nav_student.php');
?>


<body>



    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <?php
                if(isset($_POST["register_user"]))
                {
                    $username = $_POST["username"];
                   

                    $query = mysqli_query($link, "SELECT * FROM tbl_student_registration WHERE username='$username'");
                    if(mysqli_num_rows($query) > 0) {
                        echo '<div class="alert alert-danger" style="width: 100% !important;">
                The username you entered already exists.
            </div>';
                    }

                    else {
                    mysqli_query($link, "INSERT INTO tbl_student_registration 
                        VALUES('', '$_POST[last_name]', '$_POST[first_name]', '$_POST[username]', 
                        '$_POST[password]', '$_POST[email]', '$_POST[enrollment]', 'no')");
                            ?>
             <div class="alert alert-success" style="width: 100% !important;">
                Registration successfully
            </div>
            
            <?php } }
 ?>
                <form name="form1" action="" method="post">
                    <h2>User Registration Form</h2><br>

                    <div>
                        <label for="last_name">Last Name</label>
                        <input type="text" class="form-control" name='last_name' required=""/>
                    </div>

                    <div>
                        <label for="last_name">First Name</label>
                        <input type="text" class="form-control" name='first_name' required=""/>
                    </div>

                    <div>
                        <label for="last_name">Username</label>
                        <input type="text" class="form-control"  name='username' required=""/>
                    </div>

                    <div>
                        <label for="last_name">Password</label>
                        <input type="password" class="form-control"  name='password' required=""/>
                    </div>

                    <div>
                        <label for="last_name">Email</label>
                        <input type="text" class="form-control"  name='email' required=""/>
                    </div>

                    <div>
                        <label for="last_name">Student Number</label>
                        <input type="number" class="form-control" name='enrollment' required=""/>
                    </div>
                    <br>
                    <div class="">
                        <input class="btn btn-primary submit " type="submit" name="register_user" value="Register">
                    </div>

                </form>
            </div>
            </div>
        </div>


 







    </div>

   

</body>
</html>
