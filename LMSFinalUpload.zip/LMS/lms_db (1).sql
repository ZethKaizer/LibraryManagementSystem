-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2020 at 08:41 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_books`
--

CREATE TABLE `add_books` (
  `id` int(20) NOT NULL,
  `books_name` varchar(100) NOT NULL,
  `books_purchase_date` varchar(100) NOT NULL,
  `books_price` varchar(20) NOT NULL,
  `available_qty` varchar(20) NOT NULL,
  `librarian_username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_books`
--

INSERT INTO `add_books` (`id`, `books_name`, `books_purchase_date`, `books_price`, `available_qty`, `librarian_username`) VALUES
(1, 'Intro to Programming           ', '2020-01-30           ', '500  ', '3505', 'admin'),
(3, 'Encyclopedia ', '2020-03-04 ', '500 ', '60', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `issue_books`
--

CREATE TABLE `issue_books` (
  `id` int(50) NOT NULL,
  `student_enrollment` varchar(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `student_email` varchar(100) NOT NULL,
  `books_name` varchar(100) NOT NULL,
  `books_issue_date` varchar(100) NOT NULL,
  `books_return_date` varchar(100) NOT NULL,
  `status` varchar(60) NOT NULL,
  `student_username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue_books`
--

INSERT INTO `issue_books` (`id`, `student_enrollment`, `student_name`, `student_email`, `books_name`, `books_issue_date`, `books_return_date`, `status`, `student_username`) VALUES
(1, '09123456789', 'Jericho Cruz', 'jericho04@gmail.com', 'Encyclopedia', '01-03-2020', '01-03-2020', 'returned', 'jericho04'),
(2, '09123456789', 'Jericho Cruz', 'jericho04@gmail.com', 'Intro to Programming', '01-03-2020', '01-03-2020', 'returned', 'jericho04'),
(3, '09123456789', 'Jericho Cruz', 'jericho04@gmail.com', 'Encyclopedia', '01-03-2020', '01-03-2020', 'returned', 'jericho04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_librarian_registration`
--

CREATE TABLE `tbl_librarian_registration` (
  `id` int(20) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_librarian_registration`
--

INSERT INTO `tbl_librarian_registration` (`id`, `last_name`, `first_name`, `username`, `password`, `email`) VALUES
(1, 'Rei', 'John', 'admin', 'admin', 'johnrei@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_registration`
--

CREATE TABLE `tbl_student_registration` (
  `id` int(20) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `enrollment` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student_registration`
--

INSERT INTO `tbl_student_registration` (`id`, `last_name`, `first_name`, `username`, `password`, `email`, `enrollment`, `status`) VALUES
(1, 'Dela Cruz', 'John', 'johndelacruz', 'johnjohn', 'johncruz@gmail.com', '0912505050', 'yes'),
(2, 'Cruz', 'Jericho', 'jericho04', 'password', 'jericho04@gmail.com', '09123456789', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_books`
--
ALTER TABLE `add_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issue_books`
--
ALTER TABLE `issue_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_librarian_registration`
--
ALTER TABLE `tbl_librarian_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_student_registration`
--
ALTER TABLE `tbl_student_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_books`
--
ALTER TABLE `add_books`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `issue_books`
--
ALTER TABLE `issue_books`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_librarian_registration`
--
ALTER TABLE `tbl_librarian_registration`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_student_registration`
--
ALTER TABLE `tbl_student_registration`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
