<?php 
session_start();
unset($_SESSION["librarian"]);
?>
<script>
	window.location="login.php";
</script>