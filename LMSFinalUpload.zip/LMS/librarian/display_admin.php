<?php 
include('header.php');
 include('connection.php');
?>
    
        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Plain Page</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">

<!-- UPDATE QUERY -->                    
<?php 
     if(isset($_POST['updatedata'])){
      
        $id = $_POST['update_id'];
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];

        $query = mysqli_query($link, "UPDATE tbl_librarian_registration SET last_name='$last_name', first_name='$first_name', username='$username', password='$password', email='$email' WHERE id='$id'");
        if($query) {
            echo '<div class="alert alert-success" style="width: 100% !important;">
                Data Updated
            </div>';
        }
        else{
             echo '<div class="alert alert-danger" style="width: 100% !important;">
                Data Not Updated
            </div>';
        }
     }
     ?>

     <!-- DELETE QUERY -->                    
<?php 
     if(isset($_POST['deletedata'])){
      
        $id = $_POST['update_id'];
   
        $query = mysqli_query($link, "DELETE FROM tbl_librarian_registration WHERE id='$id'");
        if($query) {
            echo '<div class="alert alert-success" style="width: 100% !important;">
                Data Updated
            </div>';
        }
        else{
             echo '<div class="alert alert-danger" style="width: 100% !important;">
                Data Not Updated
            </div>';
        }
     }
     ?>




                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Plain Page</h2>
   

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <?php 
                                $res = mysqli_query($link, "SELECT * FROM tbl_librarian_registration order by ID desc");
                                ?>
                                <table class='table table-bordered table-responsive'>
                                <tr>
                                <th>ID</th>
                                <th>Last Name</th>
                                <th>First Name</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Email</th>
                                <th>Edit</th>
                                <th>Delete</th>
                                                               
                                </tr>
                                <?php while($row = mysqli_fetch_array($res)){ ?>
                                <tr>
                                <td> <?php echo $row["id"]; ?> </td>
                                <td><?php echo $row["last_name"]; ?> </td>
                                <td><?php echo $row["first_name"]; ?> </td>
                                <td><?php echo $row["username"]; ?> </td>
                                <td><?php echo $row["password"]; ?> </td>
                                <td><?php echo $row["email"]; ?> </td>
                                
                                 <td><?php echo '<button class="btn btn-primary editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td>
                                <td><?php echo '<button class="btn btn-danger deleteBtn" data-toggle="modal" data-target="#deleteBtn">Delete</button>' ?> </td>
                                </tr>
                                <?php
                                }
                                ?>
                                </table>


<!-- Modal -->
<div id="editBooks" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit Book</h4>
      </div>
       <form action="" method="post">
      <div class="modal-body">
       <input id="update_id" name="update_id" type="hidden">

         <div class="form-group">
                <label for="usr">Last Name:</label>
                <input type="text" name="last_name" id="last_name" class="form-control" required>
         </div>

         <div class="form-group">
                <label for="usr">First Name:</label>
                <input type="text" name="first_name" id="first_name" class="form-control" required>
         </div>
          <div class="form-group">
                <label for="usr">Username:</label>
                <input type="text" name="username" id="username" class="form-control" required>
         </div>

         <div class="form-group">
                <label for="usr">Password:</label>
                <input type="text" name="password" id="password" class="form-control" required>
         </div>
         <div class="form-group">
                <label for="usr">Email:</label>
                <input type="text" name="email" id="email" class="form-control" required>
         </div>

      </div>

      <div class="modal-footer">
           <button type="submit" name="updatedata" class="btn btn-primary">Update</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
     
      </div>
    </div>
  </form>
  </div>
</div>


                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
        <!-- footer content -->
        <!-- /footer content -->

    </div>
</div>

<div id="deleteBtn" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit Book</h4>
      </div>
       <form action="" method="post">
      <div class="modal-body">
       <input id="delete_id" name="update_id" type="hidden">

        <h3>Are you sure you want to delete this Book?</h3>

      </div>

      <div class="modal-footer">
         <button type="submit" name="deletedata" class="btn btn-danger">Delete</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </form>
  </div>
</div>


<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- NProgress -->
<script src="js/nprogress.js"></script>

<!-- Custom Theme Scripts -->
<script src="js/custom.min.js"></script>
<script>

    $(document).ready(function(){
        $('.editBtn').on('click', function(){
            $('#editBooks').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();

                console.log(data);

            }).get();

            $('#update_id').val(data[0]);
            $('#last_name').val(data[1]);
            $('#first_name').val(data[2]);
            $('#username').val(data[3]);
            $('#password').val(data[4]);
            $('#email').val(data[5]);
           
        });
    });
</script>

<script>

    $(document).ready(function(){
        $('.deleteBtn').on('click', function(){
            $('#deleteBooks').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();

                console.log(data);

            }).get();

            $('#delete_id').val(data[0]);
           
           
        });
    });
</script>
</body>
</html>
