<?php 
include('connection.php');
$id=$_GET["id"];
mysqli_query($link, "UPDATE tbl_student_registration SET STATUS='yes' WHERE id=$id");

?>

<script>
	window.location="demo.php";
</script>