<?php 


include('header.php');
include('connection.php');
?>
     
        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Plain Page</h3>
                    </div>

                  
                </div>

                <div class="clearfix">



                </div>
                <br>
                <?php
                if(isset($_POST["submit2"]))
                {
                    $qty = 0;
                    $res = mysqli_query($link, "SELECT * from add_books WHERE books_name='$_POST[books_name]'");
                    while($row = mysqli_fetch_array($res)) {
                        $qty = $row ["available_qty"];
                    }

                   
                    mysqli_query($link, "INSERT INTO issue_books VALUES('','$_SESSION[enrollment]', '$_POST[student_name]', '$_POST[student_email]', '$_POST[books_name]', '$_POST[books_issue_date]', '', 'pending', '$_SESSION[susername]')");

                    mysqli_query($link, "UPDATE add_books SET available_qty=available_qty-1 WHERE books_name='$_POST[books_name]'");
                            ?>
             <div class="alert alert-success" style="width: 100% !important;">
                Issued Book Successfully
            </div>
            
            <?php } 
 ?>
                <div class="row" style="min-height:500px">

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Add Books Info</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                 <form name="form1" action="" method="post" class="col-lg-7" >
                                     <table class="table">
                                        <tr>
                                            <td>
                                                <label for="enr">Student Number:</label>
                                         <select name="enr" class="form-control" placeholder="Student Number" required>
                                                    
                                                    <?php 
                                                        $res = mysqli_query($link, "SELECT enrollment from tbl_student_registration");
                                                        while($row = mysqli_fetch_array($res)) { 
                                                    

                                                  echo '<option> ';
                                                 echo $row["enrollment"]; 
                                                 echo '</option> ';
                                             }
                                                    ?>
                                                 </select>
                                             </td>
                                             <td>
                                                <label for="enrollment">Search for Student Number:</label>
                                                 <input type="submit" value="Submit" class="form-control btn btn-primary" name="submit1">
                                             </td>
                                         </tr>
                                     </table>
                                



                                 <?php 
                                 if(isset($_POST["submit1"])){
                                    //$enrollment = $_POST['enrollment'];
                                    $res5 = mysqli_query($link, 
                                        "SELECT * FROM tbl_student_registration WHERE enrollment='$_POST[enr]'"); 

                                        while($row5 = mysqli_fetch_array($res5)) {
                                            $last_name = $row5["last_name"];
                                            $first_name = $row5["first_name"];
                                            $username = $row5["username"];
                                            $email = $row5["email"];
                                            $enrollment = $row5["enrollment"];
                                            $_SESSION["enrollment"]=$enrollment;
                                            $_SESSION["susername"]=$username;
                                          }
                                    
                                     ?>

                                     <table class="table table-condensed">
                                
                                        <tr>
                                             <td>
                                                <label for="enrollment">Student Number:</label>
                                                 <input type="text" class="form-control" placeholder="" required="" name="enrollment" value="<?php echo $enrollment; ?>" required>
                                             </td>
                                         </tr>

                                         <tr>
                                             <td>
                                                <label for="enrollment">Student Name:</label>
                                                 <input type="text" class="form-control"  required="" name="student_name" value="<?php echo $first_name. ' '.$last_name; ?>">
                                             </td>
                                         </tr>


                                         <tr>
                                             <td> 
                                                <label>Student Email:</label>
                                                 <input type="text" class="form-control" placeholder="Student Email" required="" name="student_email" value="<?php echo $email; ?>">
                                             </td>
                                         </tr>

                                           <tr>
                                             <td>
                                                <label for="enrollment">Available Books:</label>
                                                 <select name="books_name" class="form-control selectpicker" placeholder="Books Name">
                                                    <?php 
                                                        $res = mysqli_query($link, "SELECT books_name from add_books");
                                                        while($row = mysqli_fetch_array($res)) { 
                                                    

                                                 echo '   <option>' ;
                                                echo $row["books_name"]; 
                                                 echo '   </option>';
                                                    } 
                                                    ?>
                                                 </select>
                                             </td>
                                         </tr>
                                         <tr>
                                             <td>
                                                <label for="enrollment">Issued Date:</label>
                                                 <input type="text" class="form-control" placeholder="Books Issue Date" required="" name="books_issue_date"value="<?php echo date("d-m-Y"); ?>" required>
                                             </td>
                                         </tr>
                                         <tr>
                                             <td>
                                                <label for="enrollment">Username:</label>
                                                 <input type="text" class="form-control" placeholder="Student Username" required="" name="student_username" value="<?php echo $username; ?>">
                                             </td>
                                         </tr>



                                         <tr>
                                             <td>
                                                 <input type="submit" class="btn btn-primary submit2"  value="Insert Issue Books" name="submit2">
                                             </td>
                                         </tr>


                                     </table>

                                 <?php } ?>
                             </form>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
      
    </div>
</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- NProgress -->
<script src="js/nprogress.js"></script>

<!-- Custom Theme Scripts -->
<script src="js/custom.min.js"></script>
</body>
</html>
