<?php 
//session_start();
include('header.php');
include('connection.php');

?>

     
        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Plain Page</h3>
                    </div>

                    <div class="title_right">

                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix">
                        
                </div>
                 <?php
                if(isset($_POST["register_user"]))
                {
                    $username = $_POST["username"];
                   

                    $query = mysqli_query($link, "SELECT * FROM tbl_librarian_registration WHERE username='$username'");
                    if(mysqli_num_rows($query) > 0) {
                        echo '<div class="alert alert-danger" style="width: 100% !important;">
                The username you entered already exists.
            </div>';
                    }

                    else {
                    mysqli_query($link, "INSERT INTO tbl_librarian_registration 
                        VALUES('', '$_POST[last_name]', '$_POST[first_name]', '$_POST[username]', 
                        '$_POST[password]', '$_POST[email]')");
                            ?>
             <div class="alert alert-success" style="width: 100% !important;">
                Registration successfully
            </div>
            
            <?php } }
 ?>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Add Admin Info</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                 <form name="form1" action="" method="post" class="col-lg-6" >
                                     <table class="table">
                                        <tr>
                                             <td>
                                                 <label for="books_name">Last Name</label>
                                                 <input type="text" class="form-control"  name='last_name' required=""/>
                                             </td>
                                         </tr>

                                         <tr>
                                             <td>
                                                 <label for="books_purchase_date">First Name</label>
                                                <input type="text" class="form-control" name='first_name' required=""/>
                                             </td>
                                         </tr>

                                         <tr>
                                             <td><label for="books_price">Username</label>
                                                 <input type="text" class="form-control"  name='username' required=""/>
                                             </td>
                                         </tr>
                                         
                                         <tr>
                                             <td>
                                                <label for="available_qty">Password</label>
                                                 <input type="password" class="form-control"  name='password' required=""/>
                                             </td>
                                         </tr>
                                     

                                         <tr>
                                             <td>
                                                <label for="available_qty">Email</label>
                                                  <input type="text" class="form-control"name='email' required=""/>
                                             </td>
                                         </tr>

                                         <tr>
                                             <td>
                                                <label for="available_qty">Enrollment Number:</label>
                                                 <input type="text" class="form-control" p name='enrollment' required=""/>
                                             </td>
                                         </tr>



                                         <tr>
                                             <td>
                                                 <input class="btn btn-default submit " type="submit" name="register_user" value="Register">
                                             </td>
                                         </tr>


                                     </table>

                                 </form>

                            </div>

                        </div>

          

                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->


        
     
        <!-- footer content -->

    </div>
</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- NProgress -->
<script src="js/nprogress.js"></script>

<!-- Custom Theme Scripts -->
<script src="js/custom.min.js"></script>
</body>
</html>
