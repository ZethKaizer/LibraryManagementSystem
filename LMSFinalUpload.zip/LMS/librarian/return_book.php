<?php 
//session_start();
include('header.php');
include('connection.php');

?>
     
        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Plain Page</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>My Issued Books</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <?php 
                           //     $susername = $_SESSION['username'];
                                $res = mysqli_query($link, "SELECT * FROM issue_books");
                                ?>
                                <table class='table table-bordered table-responsive'>
                                <tr>
                                <th>Student Enrollment No </th>
                                <th>Student Name </th>
                                <th>Student Email</th>
                                <th>Book Name</th>
                                <th>Book Issue Date</th>
                                <th>Book Return Date</th>
                                <th>Status</th>
                                <th>Return Books</th>  
                                </tr>
                                <?php while($row = mysqli_fetch_array($res)){ ?>
                                <tr>
                                <td><?php echo $row["student_enrollment"]; ?> </td>
                                <td><?php echo $row["student_name"]; ?> </td>
                                <td><?php echo $row["student_email"]; ?> </td>
                                <td><?php echo $row["books_name"]; ?> </td>
                                <td><?php echo $row["books_issue_date"]; ?> </td>   
                                 <td><?php echo $row["books_return_date"]; ?> </td>  
                                  <td><?php echo $row["status"]; ?> </td>  
                                <td><a 
                                    <?php if($row["status"]=='pending') { 
                                        echo 'class="btn btn-primary"';
                                    }
                                    else{
                                        echo 'class="btn btn-primary disabled"';
                                    }
                                    ?>
                                    href="return.php?id=<?php echo $row["id"]; ?>">Return Books</a></td>
                                </tr>
                                <?php
                                }
                                ?>
                                </table>



                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
        <!-- footer content -->
        <!-- /footer content -->

    </div>
</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- NProgress -->
<script src="js/nprogress.js"></script>

<!-- Custom Theme Scripts -->
<script src="js/custom.min.js"></script>
</body>
</html>
