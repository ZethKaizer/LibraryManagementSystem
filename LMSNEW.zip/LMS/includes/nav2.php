<?php 
require 'includes/db-inc.php';


 ?>
<nav class="navbar navbar-expand-md navbar-dark fixed-top" style="background: #003399; zoom: 90%;">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example">
                <span class="sr-only">:</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">LMS</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php">View Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="borrow-student.php">Borrow Books</a></li>
				<li class="nav-item"><a class="nav-link" href="fine-student.php">Fines</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>