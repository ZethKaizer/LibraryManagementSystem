<?php 
session_start();
// session_destroy();
// if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
// 	header("Location: admin.php?access=false");
// 	exit();
// }
// else {
// 
// }
if (isset($_SESSION['admin'])) {
     $admin = $_SESSION['admin'];
}

if (isset($_SESSION['student-name'])) {
     $student = $_SESSION['student-name'];
   
}
?>



<nav class="navbar navbar-expand-md  navbar-dark fixed-top" style="background: #003399; zoom: 90%;">
    <div class="container-fluid">
        <div class="navbar-header">
           
            <a class="navbar-brand" href="#">LMS</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example">
            <ul class="navbar-nav ml-auto">
                <?php if(isset($admin)) { ?>  
                <li class="nav-item"><a class="nav-link" href="admin.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="bookstable.php">Books</a></li>
                <li class="nav-item"><a class="nav-link" href="users.php">Admins</a></li>
                <li class="nav-item"><a class="nav-link" href="viewstudents.php">Students</a></li>
                <li class="nav-item"><a class="nav-link" href="borrowedbooks.php">Borrow books</a></li>
                <br>
                <!--
                <li class="nav-item"><a class="nav-link" href="fines.php">Fines</a></li>
                <?php } ?>
                -->
            </ul> 
     
            <ul class="nav navbar-nav navbar-right">
                <li class="nav-item"><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>