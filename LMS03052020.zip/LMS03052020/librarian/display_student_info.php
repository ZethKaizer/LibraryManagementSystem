<?php 
include('header.php');
 include('connection.php');
?>

     
        <!-- page content area main -->
        <div class="container" style="margin-top: 20px;">
            <div class="">
               

              
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <center>
                                <h2>Add Student Info</h2>
                            </center>
                            <br>
                                
                            </div>
                            <div class="x_content">
                                <?php 
                                $res = mysqli_query($link, "SELECT * FROM tbl_student_registration");
                                ?>
                                <table class='table table-bordered table-striped'>
                                <tr style="background: #d9d9d9 !important; text-align: center;">
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Email</th>
                                <th>Enrollment</th>
                                <th>Status</th>
                                <th>Approval</th>
                                
                                </tr>
                                <?php while($row = mysqli_fetch_array($res)){ ?>
                                <tr>
                                <td><?php echo $row["first_name"]; ?> </td>
                                <td><?php echo $row["last_name"]; ?> </td>
                                <td><?php echo $row["username"]; ?> </td>
                                <td><?php echo $row["password"]; ?> </td>
                                <td><?php echo $row["email"]; ?> </td>
                                <td><?php echo $row["enrollment"]; ?> </td>
                                <td><?php echo $row["status"]; ?> </td>
                                <td> 

                                <div class="dropdown">
                                  <button class="btn dropdown-toggle btn-primary"  type="button" data-toggle="dropdown"> Account Approval
                                  <span class="caret"></span></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="approve.php?id=<?php echo $row["id"]; ?>">Approve</a>
                                    <a class="dropdown-item" href="notapprove.php?id=<?php echo $row["id"]; ?>">Not Approve</a>
                                  </div>
                                </div>
                                 </td>

                                
                                
                                </tr>
                                <?php
                                }
                                ?>
                                </table>



                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
        <!-- footer content -->
        <!-- /footer content -->

    </div>
</div>

<!-- jQuery -->

</body>
</html>
