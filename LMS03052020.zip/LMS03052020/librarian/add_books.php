<?php 
//session_start();
include('header.php');
include('connection.php');

?>

     
        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Plain Page</h3>
                    </div>

                    <div class="title_right">

                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix">
                        
                </div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Add Books Info</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                 <form name="form1" action="" method="post" class="col-lg-6" >
                                     <table class="table">
                                        <tr>
                                             <td>
                                                 <label for="books_name">Book Name</label>
                                                 <input type="text" class="form-control"  required="" name="books_name">
                                             </td>
                                         </tr>

                                         <tr>
                                             <td>
                                                 <label for="books_purchase_date">Book Purchase Date</label>
                                                 <input type="date" class="form-control"  required="" name="books_purchase_date">
                                             </td>
                                         </tr>

                                         <tr>
                                             <td><label for="books_price">Book Price</label>
                                                 <input type="number" class="form-control"  required="" name="books_price">
                                             </td>
                                         </tr>
                                         <!--
                                         <tr>
                                             <td>
                                                <label for="available_qty">Book Quantity</label>
                                                 <input type="number" class="form-control" required="" name="books_qty">
                                             </td>
                                         </tr>
                                     -->

                                         <tr>
                                             <td>
                                                <label for="available_qty">Book Quantity</label>
                                                 <input type="number" class="form-control" required="" name="available_qty">
                                             </td>
                                         </tr>

                                         <tr>
                                             <td>
                                                 <input type="submit" class="btn btn-primary" placeholder="Librarian Username" value="Add Book" name="submit1">
                                             </td>
                                         </tr>


                                     </table>

                                 </form>

                            </div>

                        </div>

         <?php
                if(isset($_POST["submit1"]))
                {
                    $books_name = $_POST["books_name"];
                   

                    $query = mysqli_query($link, "SELECT * FROM add_books WHERE books_name='$books_name'");
                    if(mysqli_num_rows($query) > 0) {
                        echo '<div class="alert alert-danger" style="width: 100% !important;">
                The book you entered already exists.
            </div>';
                    }

                    else {
                        $books_name = $_POST["books_name"];
            $books_purchase_date = $_POST["books_purchase_date"];
            $books_price = $_POST["books_price"];
            $available_qty = $_POST["available_qty"];
            $librarian = $_SESSION["librarian"];

                   mysqli_query($link, "INSERT INTO add_books VALUES('','$books_name', '$books_purchase_date', '$books_price', '$available_qty', '$librarian')");
                            ?>
             <div class="alert alert-success" style="width: 100% !important;">
                Inserted successfully
            </div>
            
            <?php } }
 ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->


        
     
        <!-- footer content -->

    </div>
</div>


</body>
</html>
