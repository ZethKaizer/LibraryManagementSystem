  <?php 
  include('connection.php');

     if(isset($_POST['updatedata'])){
      
        $id = $_POST['update_id'];
        $books_name = $_POST['books_name'];
        $books_purchase_date = $_POST['books_purchase_date'];
        $books_price = $_POST['books_price'];
        $available_qty = $_POST['available_qty'];

        $query = mysqli_query($link, "UPDATE add_books SET books_name='$books_name', books_purchase_date='$books_purchase_date', books_price='$books_price', available_qty='$available_qty' WHERE id='$id'");
        if($query) {
            echo '<script> alert("Data Updated"); </script>';
            echo '<script> window.location = "display_books.php" </script>';
        }
        else{
            echo '<script> alert("Data Not Updated"); </script>';
        }
     }
     ?>