<?php 
include('connection.php');
$id=$_GET["id"];
mysqli_query($link, "UPDATE tbl_student_registration SET STATUS='no' WHERE id=$id");

?>

<script>
	window.location="display_student_info.php";
</script>