<?php 
session_start();
    include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Libarian Login Form | LMS </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">

    <style>

    </style>
</head>

<br>

<body style="background: #ffcc80;">

<div class="container">

    <h2 class="text-center p-4">Library Management System</h2>
    <div class="row justify-content-center">
        <div class="col-lg-4 bg-light mt-2 px-0" style="background: white !important; border: solid 1px #d8dee2 !important; border-radius: 10px;">
        
        <form action="" method="post" class="p-4">

        <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" class="form-control form-control" required>
        </div>
        <div class="form-group">
            <label for="usr">Password:</label>
            <input type="password" name="password" class="form-control form-control" required>
        </div>
        <!--
        <div class="btn-group btn-group-toggle form-group" data-toggle="buttons" style="width: 100% !important;">
              <label for='regular'  class="btn btn-outline-dark ">
                  <input type="radio" class="custom-control-input" required id="regular" name="employee_type" value="regular"/>Admin
              </label>
              <label for='Job Order' class="btn btn-outline-dark">
                <input type="radio" class="custom-control-input" required id="Job Order" name="employee_type" value="Job Order"/>User
              </label>
          </div>
      -->

        <div class="form-group">
            <span><input type="submit" class="btn btn-block" style="background-color: #ffad33;" value="Login" name="login_user"></span>
        </div>
        </form>
    </div>
</div>
</div>

</div>
<?php 
    if(isset($_POST["login_user"])){
        $count = 0;
        $res=mysqli_query($link, "SELECT * FROM tbl_librarian_registration 
                          WHERE username='$_POST[username]' && password='$_POST[password]'");
        $count=mysqli_num_rows($res);

        if($count==0){
            ?>
            <div class="alert alert-danger col-lg-6 col-lg-push-3">
                <strong>Invalid</strong> Username Or Password.
            </div>
<?php
        }
        else {
            $_SESSION["librarian"] = $_POST["username"];
            ?>
            <script>
                window.location="display_student_info.php";
            </script>
            <?php
        }
    }
?>


</body>
</html>
