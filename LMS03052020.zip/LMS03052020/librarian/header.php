<?php
    session_start();
    
    if(!isset($_SESSION["librarian"])) {

        ?>
        <script>
            window.location = "login.php";
        </script>
        <?php
        include('connection.php');
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Plain Page | LMS </title>

    
    <style>
        .nav-link {
            font-size: 14px;
            color: #303030 !important;
        }
        .nav-link:hover {
          color: black !important;
        }
    </style>
</head>

<!-- <?php echo $_SESSION["librarian"]; ?></h2> -->
<body>

<nav class="navbar navbar-expand-lg navbar-light" style="background: #ffb366;">
        <img src="images/PUPLogo.png" width="50"> &nbsp;&nbsp;
      <a class="navbar-brand" href="#">Library Management System</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
                
                <li class="nav-item active">
                  <a class="nav-link" style="font-size: 16px;">Welcome, <b><?php echo $_SESSION["librarian"]; ?></b> |<span class="sr-only"></h2> </span></a>
                </li>
          

             <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                      Manage User Credentials
                    </a>
                    <div class="dropdown-menu">

                      <a class="dropdown-item" href="display_student_info.php">Add Student Info</a>
                      <a class="dropdown-item" href="registration.php">Add Admin Info</a>
                      <a class="dropdown-item" href="display_admin.php">Display Admin Info</a>
                    </div>
                  </li>   


             

                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                      Manage Books
                    </a>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" href="add_books.php">Add Books</a>
                      <a class="dropdown-item" href="display_books.php">Display Books</a>
                      <a class="dropdown-item" href="issue_books.php">Issue Books</a>
                      <a class="dropdown-item" href="return_book.php">Return Books</a>
                    </div>
                  </li>    
                 <li class="nav-item">
                  <a class="nav-link" href="logout.php">Log Out</a>
                </li>    
          </ul>
      </div>
    </nav>
</body>

<!-- TAGS -->
       
<!-- To make your web page responsive --> 
  

<!-- These tags are support for Bootstrap's CSS and Javscript from Bootstrap.-->

  <!-- Latest compiled and minified CSS -->
  <link href="css/bootstrap.css" rel="stylesheet">
  <link href="css/bootstrap-grid.css" rel="stylesheet">
<link href="css/bootstrap-grid.min.css" rel="stylesheet">

  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- jQuery library -->
  
  <!-- Latest compiled JavaScript -->
  <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Link for Bootstrap Icons -->
  <link rel="stylesheet" href="css/all.css">
  <script src="js/all.js"></script>

  <!-- Link to style web page (CSS Link) -->
  <link rel="stylesheet" type="text/css" href="css/style.css">

   


