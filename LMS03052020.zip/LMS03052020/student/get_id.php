<?php 
$id = $_GET["id"];
$a = date("d-m-Y");
$res2 = mysqli_query($link, "UPDATE issue_books SET books_return_date='$a', status='returned' WHERE id=$id");
?>