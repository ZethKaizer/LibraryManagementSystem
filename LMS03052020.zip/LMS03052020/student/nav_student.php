<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Library Management System</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li class=""><a href="login.php">Login</a></li>
      <li><a href="registration.php">Register</a></li>
    </ul>
  </div>
</nav>