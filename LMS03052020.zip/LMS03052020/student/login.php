<?php 
session_start();
    include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Student Login Form | LMS </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
</head>

<?php include('nav_student.php');
?>
<body>


<div class="container ">

    <div class="row">
        <div class="col-md-4 col-md-offset-4">
        <form name="form1" action="" method="post">
            <h1>User Login Form</h1>
            <br>

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" class="form-control" required=""/>
            </div>
            <div>
                <label for="username">Password</label>
                <input type="password" name="password" class="form-control"required=""/>
            </div>
            <br>
            <div>

                <input class="btn btn-primary submit" type="submit" name="login_user" value="Login">
                
            </div>

            <div class="clearfix"></div>

            
                <div class="clearfix"></div>
                <br/>
</form>
            </div>
            </div>
        
   </div>

</div>
<?php 
    if(isset($_POST["login_user"])){
        $count = 0;
        $res=mysqli_query($link, "SELECT * FROM tbl_student_registration 
                          WHERE username='$_POST[username]' && password='$_POST[password]' && status='yes'");
        $count=mysqli_num_rows($res);

        if($count==0){
            ?>
            <div class="alert alert-danger col-lg-6 col-lg-push-3">
                <strong>Invalid</strong> Username Or Password.
            </div>
<?php
        }
        else {
            $_SESSION["username"] = $_POST["username"];
            ?>
            <script>
                window.location="my_issued_books.php";
            </script>
            <?php
        }
    }
?>


</body>
</html>
