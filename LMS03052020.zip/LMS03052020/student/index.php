<?php 
session_start();
    include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Student Login Form | LMS </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

</head>


<body>
<?php 
    include('nav_student.php');
?>
<div class="container">
  <div class="jumbotron">
    <h1>Library Management System</h1>      
   <!-- <p>Bootstrap is the most popular HTML, CSS, and JS framework for developing responsive, mobile-first projects on the web.</p>  Kayo na bahala maglagay dito ng description hehe. -->
  </div>
  <p>This is some text.</p>      
  <p>This is another text.</p>      
</div>
</body>




</html>
